import React from 'react';
const Home: React.FC = () => (
  <div>
    <h1>Bem-vindo ao Organizo!</h1>
  </div>
);
export default Home;
