package com.organizo.organizobackend.util;

public class JwtUtilTest {
}
