package com.organizo.organizobackend.controller;

public class ClienteControllerIntegrationTest {
}
