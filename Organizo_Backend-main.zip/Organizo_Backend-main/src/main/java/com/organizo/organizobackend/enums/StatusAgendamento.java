package com.organizo.organizobackend.enums;

public enum StatusAgendamento {
    PENDENTE,
    CONFIRMADO,
    CANCELADO,
    CONCLUIDO
}
