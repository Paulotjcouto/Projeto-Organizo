package com.organizo.organizobackend.enums;

public enum CargoProfissional {
    MANICURE,
    PEDICURE,
    CABELEIREIRO,
    DEPILADORA,
    MAQUIADORA,
    ESTETICISTA
}
